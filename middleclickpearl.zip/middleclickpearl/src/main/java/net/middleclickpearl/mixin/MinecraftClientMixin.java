package net.middleclickpearl.mixin;

import net.middleclickpearl.MiddleClickPearlClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla binds middle click to "pick block", which would swap your hotbar slot
 * when looking at a block. While you have a pearl in the hotbar we skip that,
 * so middle click only throws the pearl. Without a pearl, pick block works as usual.
 * require = 0: if this target ever changes, the mod still works (pick block just stays active).
 */
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "doItemPick", at = @At("HEAD"), cancellable = true, require = 0)
    private void middleclickpearl$skipPick(CallbackInfo ci) {
        if (MiddleClickPearlClient.shouldSuppressPickBlock((MinecraftClient) (Object) this)) {
            ci.cancel();
        }
    }
}

package net.middleclickpearl;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class MiddleClickPearlClient implements ClientModInitializer {

    /** Middle mouse button by default; can be rebound in Controls. */
    public static KeyBinding THROW_KEY;

    @Override
    public void onInitializeClient() {
        THROW_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.middleclickpearl.throw",
                InputUtil.Type.MOUSE,
                GLFW.GLFW_MOUSE_BUTTON_MIDDLE,
                "category.middleclickpearl"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (THROW_KEY.wasPressed()) {
                throwPearl(client);
            }
        });
    }

    /** Returns the hotbar slot (0-8) holding an ender pearl, or -1. */
    private static int findPearlSlot(PlayerInventory inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.ENDER_PEARL)) return i;
        }
        return -1;
    }

    /** Used by the mixin: true if middle click should NOT do vanilla "pick block" right now. */
    public static boolean shouldSuppressPickBlock(MinecraftClient client) {
        if (client.player == null || client.currentScreen != null) return false;
        return findPearlSlot(client.player.getInventory()) >= 0;
    }

    private static void throwPearl(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;
        if (client.currentScreen != null || player.isSpectator()) return;

        PlayerInventory inv = player.getInventory();
        int slot = findPearlSlot(inv);
        if (slot < 0) return;
        if (player.getItemCooldownManager().isCoolingDown(inv.getStack(slot))) return;

        // Select the pearl, use it, and put the previous slot back within the same tick.
        // interactItem() syncs the slot change to the server before sending the "use" packet,
        // and the vanilla per-tick sync then sends the switch back to the original slot.
        int previous = inv.selectedSlot;
        inv.selectedSlot = slot;
        ActionResult result = client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        if (result.isAccepted()) {
            player.swingHand(Hand.MAIN_HAND);
        }
        inv.selectedSlot = previous;
    }
}
